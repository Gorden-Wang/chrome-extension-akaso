import React from 'react';

export default function Log(user = []) {
  return (
    <div className="log_wrap">

    </div>
  )
}